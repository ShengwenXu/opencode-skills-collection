---
name: "soil-microbe-integrated-analysis"
description: "土壤理化与微生物数据联合分析：变量筛选与共线性、RDA/CCA/db-RDA、方差分解、Mantel、piecewiseSEM、共现网络规范"
---

# 土壤理化与微生物联合分析（R）

用于把土壤理化/酶活数据与微生物群落数据（扩增子、宏基因组、PLFA、qPCR）整合起来，回答"环境因子如何驱动群落"这类问题。核心不是跑出一个显著的 RDA，而是让分析设计与采样设计匹配。

工具栈：`vegan`（约束排序、Mantel）、`ade4`（多种约束排序）、`microeco`（一体化流程）、`piecewiseSEM` / `lavaan`（结构方程）、`igraph` + `SpiecEasi`（共现网络）。

## 一、先做变量筛选，再做约束排序

约束排序的样本数约束比 PERMANOVA 更紧：**解释变量数必须远小于样本数**。经验门槛：样本数 / 解释变量数 ≥ 5，理想 ≥ 10。20 个样点放 12 个理化指标进 RDA，得到的显著结果没有意义。

```r
# 1. 理化指标之间的共线性检查
env <- read.csv("soil_properties.csv", row.names = 1)
library(corrplot); library(Hmisc)
rc <- rcorr(as.matrix(env), type = "spearman")
corrplot(rc$r, p.mat = rc$P, insig = "blank", type = "upper")
# |r| > 0.7 的指标二选一（保留生态学上更基础的那个，如 pH 优于交换性酸）

# 2. 方差膨胀因子，VIF > 10 的要剔除
library(usdm)
vifcor(env, th = 10)   # 自动给出建议保留的变量集

# 3. 前向选择（受约束的，用置换检验）
d_bc <- vegdist(otu_table(clr_ps), "euclidean")
mod0 <- dbrda(d_bc ~ 1, data = env)
mod1 <- dbrda(d_bc ~ ., data = env)
sel <- ordiR2step(mod0, mod1, R2scope = TRUE, permutations = 999, direction = "forward")
sel$anova   # 看累积调整 R² 停止在哪
```

注意 `ordiR2step` 的 R²scope 会用全模型的调整 R² 作为上限，防止过拟合。结果里的"被选入变量"才是后续分析的依据，不要用一开始的 12 个指标。

## 二、约束排序：方法选择

| 方法 | 何时用 | 关键点 |
|---|---|---|
| **RDA** | 梯度短（DCA 轴长 < 3），线性响应 | 用 CLR/Aitchison 距离（`dbrda` + euclidean on CLR） |
| **CCA** | 梯度长（DCA > 4），单峰响应 | 用原始 counts，CCA 对稀有类群敏感 |
| **db-RDA** | 任意距离（Bray-Curtis、UniFrac） | 最通用；`capscale` 或 `dbrda` |
| **CAP** | 需要按已知分组做约束 | 常配 `wcmdscale` |

```r
# 先看梯度长度决定线性还是单峰
decorana(otu_table(ps_rare))
# 轴长 < 3 -> RDA/db-RDA；> 4 -> CCA；3-4 之间 -> 两种都做，看解释力

# db-RDA（推荐）
mod <- dbrda(d_bc ~ pH + SOC + C.N + Moisture, data = env)
anova(mod, permutations = 999)                    # 整体
anova(mod, by = "margin", permutations = 999)     # 各因子边际效应
RsquareAdj(mod)                                   # 调整 R²，报告这个而不是原始 R²

# 每个轴的解释率
summary(eigenvals(mod, model = "constrained")) / sum(eigenvals(mod))

# 出图
plot(mod, display = c("sites", "bp"), scaling = 2)
```

**报告调整 R²**，不是原始 R²。原始 R² 随变量数上升，20 个样本 5 个变量能轻松得到 R²=0.4 而调整后接近 0。

## 三、方差分解：区分共同解释与独立解释

单个 RDA 只能说明"这些因子合起来解释了 X%"。要回答"pH 和有机质哪个更重要、有多少是共同的"，用方差分解。

```r
library(vegan)
vp <- varpart(d_bc, ~ pH, ~ SOC, ~ Clay, data = env)
vp
plot(vp, Xnames = c("pH", "SOC", "Clay"), bg = 2:4)
# 报告：[a] 纯 pH、[b] 纯 SOC、[c] 纯 Clay、各交集、[Residual]
```

方差分解的负值调整值可能出现（说明该组变量解释力低于随机水平），报告时要说明，不能直接舍去当作 0。

样本数少于 30 时，方差分解的各个分数不稳定，务必做置换检验（`anova` 在每个 fraction 上）或至少报告置信区间。

## 四、Mantel 与偏 Mantel

适用于**距离矩阵之间**的关系（如群落距离 vs 地理距离、vs 理化距离）。不要用它替代 RDA——Mantel 只给一个总体相关，不给方向和各因子的相对重要性。

```r
d_env <- vegdist(scale(env), "euclidean")
d_geo <- vegdist(coords, "euclidean")   # 地理距离

mantel(d_bc, d_env, method = "spearman", permutations = 999)
# 偏 Mantel：控制地理距离后，环境对群落的独立效应
mantel.partial(d_bc, d_env, d_geo, method = "spearman", permutations = 999)

# 距离衰减：mantel 相关随距离分段变化
```

Mantel 的常见误用：用 Mantel 检验一个已经包含在 RDA 里的关系，然后说"两者一致"。这不是独立验证。

## 五、结构方程模型（因果推断）

土壤微生物研究里最常见的 SEM 误用：把相关性当因果，或样本数与路径数不匹配。

样本数规则：**每个待估参数至少 5 个样本，理想 10 个**。10 个路径的模型需要至少 50–100 个样本。样本不够就改用 piecewiseSEM（局部估计，对样本量要求宽松些）或干脆不做 SEM，用方差分解 + 分层回归。

```r
library(piecewiseSEM)
model <- psem(
  lm(SOC ~ Clay + pH, data = env),
  lm(MicrobialBiomass ~ SOC + pH, data = env),
  lm(Shannon ~ MicrobialBiomass + pH, data = env),
  lmer(Function ~ Shannon + SOC + (1|Block), data = env)   # 可混入混合模型
)
summary(model)   # 看 Fisher's C 与 d-separation 检验
# Fisher's C 的 p > 0.05 表示模型与数据不矛盾（注意：不是"模型正确"）
```

必须报告：Fisher's C、p 值、AIC、以及所有**不显著**的路径（审稿人会核对自由度）。删除不显著路径后要重新拟合，并报告删除的依据。

## 六、共现网络

网络分析是被过度使用的方法。先问：**网络能回答什么我的其他分析回答不了的问题？** 网络给的是共现模式，不是相互作用。所有"某某菌与某某菌协同作用"的表述都需要实验证据。

```r
library(SpiecEasi)   # 组成型数据推荐
se <- spiec.easi(as.matrix(t(otu_table(ps_rel))), method = "mb",
                 lambda.min.ratio = 1e-2, nlambda = 20,
                 pulsar.params = list(rep.num = 50))
adj <- as.matrix(getRefit(se))

library(igraph)
g <- graph_from_adjacency_matrix(adj, mode = "undirected", diag = FALSE)
# 网络指标：模块度、平均度、聚类系数、正/负相关比例
```

关键规范：
- 每组的样本数 < 20 时不要做网络，边大部分是噪声。
- 分组网络比较（如不同处理vs对照）必须用**相同的节点集和相同的 λ**，否则模块度差异反映的是参数差异。用 `SpiecEasi` 的 `shuffle` 或 bootstrap 检验。
- 网络图必须给 bootstrap 稳定性（每条边被重抽样检出的比例），只画稳定的边。
- 不用单一网络的模块度来推断"处理增强了群落稳定性"——这个推断需要多组重复网络 + 稳定性指标的统计比较。

## 七、酶活与功能指标的整合

土壤酶活（β-葡萄糖苷酶、脲酶、磷酸酶等）通常是绝对活性（nmol g⁻¹ h⁻¹），不是组成型数据。可以和理化指标一起进 RDA（作为解释变量），也可以作为响应变量做回归。

常见分析：酶活化学计量比（C:N:P 获取酶比）反映养分限制，用 `ggplot` 画向量图或在 RDA 里作为响应。这里要注意"酶活反映微生物需求"vs"酶活反映微生物生物量"的混淆——前者需要按微生物量归一，后者不用。论文里要写清归一方式。

## 八、常见错误清单

- 解释变量数 ≥ 样本数/5 就做约束排序。
- 报告原始 R² 而非调整 R²。
- 方差分解出现负值不做说明。
- 用 Mantel 替代 RDA 回答"哪个因子更重要"。
- SEM 样本数不足仍估计大量路径，且不报告不显著路径。
- Fisher's C 的 p > 0.05 被写成"模型被验证"（只能说未被拒绝）。
- 网络分析不报 bootstrap 稳定性，直接解释模块与枢纽物种。
- 把共现当互作。
- 理化指标未做共线性处理（VIF 未看）。
- 不同处理组的网络用不同参数比较模块度。

