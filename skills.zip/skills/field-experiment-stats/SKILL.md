---
name: "field-experiment-stats"
description: "田间与盆栽试验统计：模型与随机化结构对齐、裂区/重复测量建模、DHARMa 残差诊断、emmeans 多重比较、功效分析"
---

# 生态与田间试验统计（R）

用于田间试验、盆栽试验、定位试验的分组比较与因子设计分析。核心是把统计模型与实验设计对齐——土壤与微生物研究里最常见的统计错误是模型没有反映随机化结构。

工具栈：`lme4` / `glmmTMB`（混合模型）、`lmerTest`（p 值）、`DHARMa`（残差诊断）、`emmeans`（多重比较）、`performance`（模型检查）。

## 一、先画实验结构图，再选模型

写模型之前，把设计写成一个句子：**处理因子有哪些、怎么随机化、重复的单位是什么、时间上是重复测量还是独立采样。**

田间试验的典型层次：区组（Block）→ 小区（Plot）→ 采样点（Subplot）→ 时间点。凡是"同一小区在不同时间采样多次"，时间就是重复测量，模型里必须有小区随机效应，否则产生伪重复（pseudoreplication），p 值会系统性偏小。

```r
# 结构检查
table(meta$Treatment, meta$Block)   # 每个区组里每个处理各一个小区 = 裂区/随机完全区组
length(unique(meta$Plot))           # 小区数
table(meta$Plot, meta$Time)         # 每小区多时点 = 重复测量
```

## 二、模型选择的决策路径

**完全随机设计、单因子、独立样本**：`aov(y ~ Treatment)`，等价于 `lm`。前提：残差正态 + 方差齐性。

**随机完全区组（RCBD）**：`lmer(y ~ Treatment + (1|Block))`。区组效应必须是随机而非固定，因为在推断上你想推广到"类似的田块"，不是只针对这几个区组。

**裂区设计（split-plot）**：主区因子（如灌溉）整块随机化，副区因子（如施肥）在主区内随机化。模型必须有两层误差：

```r
lmer(y ~ Irrigation * Fertilizer + (1|Block/Irrigation), data = meta)
# 注意 (1|Block/Irrigation) 展开为 (1|Block) + (1|Block:Irrigation)
# 主区因子 Irrigation 的错误项是 Block:Irrigation，不是残差
```

写裂区模型时如果只用 `(1|Block)`，主区因子的 p 值会明显偏小，这是审稿人常抓的点。

**重复测量 / 时间序列**：`lmer(y ~ Treatment * Time + (1|Plot) + (1|Block))`。若时间点间的自相关重要，用 `nlme::lme` 加 `corAR1()` 或 `glmmTMB` 加 `ar1(Time + 0 | Plot)`。

**嵌套设计**：`lmer(y ~ Treatment + (1|Site/Plot))`。

**非正态响应**：计数用 `glmer.nb` 或 `glmmTMB(..., family = nbinom2)`；比例（如 0–1 的酶活与生物量比）用 `glmmTMB(..., family = beta_family)`；存在零膨胀的计数用 `glmmTMB` 的 `ziformula`。不要对计数数据直接 `log(x+1)` 后套 ANOVA——现代做法是直接用合适分布的 GLMM，或者至少把 log 变换的模型与 GLMM 结果交叉验证。若必须变换（如拷贝数跨多个数量级），对数变换是合理的，要在方法里写明底数。

## 三、残差诊断：不做这一步的分析不能发表

```r
library(DHARMa)
m <- lmer(y ~ Treatment + (1|Block), data = meta)
res <- simulateResiduals(m, plot = TRUE)
testResiduals(res)          # 统一性、离散度、零膨胀、离群值
testDispersion(res)
testZeroInflation(res)
testOutliers(res, type = "bootstrap")

# 检查随机效应结构是否合理
library(performance)
check_singularity(m)        # 奇异拟合 = 随机效应方差估计为 0，模型过复杂
icc(m)                      # 组内相关，判断区组效应是否值得保留
r2(m)                       # 边际 R² 与条件 R²
```

DHARMa 的 QQ 图不是正态 QQ 图，它检验的是模拟残差的整体分布，不要用 `qqnorm(resid(m))` 代替。

随机效应保留的判据：ICC 接近 0 且 `check_singularity` 报警时，可以去掉该随机效应；但若去掉会改变固定效应结论，要报告两种模型。不要用 p 值来决定保留哪个随机效应（边界检验的 p 值不成立）。

## 四、多重比较

```r
library(emmeans)
emm <- emmeans(m, ~ Treatment)
pairs(emm, adjust = "tukey")          # 两两比较
# 有交互时不要只比主效应
emm2 <- emmeans(m, ~ Treatment | Time)
pairs(emm2, adjust = "sidak")

# 与对照比：Dunnett 比 Tukey 更有功效
contrast(emm, method = "trt.vs.ctrl", ref = "CK", adjust = "dunnett")

# 用 CLD 字母标记（论文常用）
library(multcomp); library(multcompView)
cld(emm, Letters = letters, adjust = "tukey")
```

校正方式选择：与对照比用 Dunnett；所有两两比用 Tukey（平衡设计）或 Holm（不平衡）；探索性多变量用 BH（FDR）。**不要在同一批比较里混用不同校正然后又合并解释。**

报告给：均值 ± SE（或 95% CI）、n、以及 p 值。误差棒要说明是 SE 还是 SD——论文里最常见的不规范是柱状图不注明。

## 五、功效与样本量

论文的"局限"部分写"样本量有限"没有信息量。要么做功效分析说明能检出多大效应，要么说明本设计的可检出效应下限。

```r
library(simr)
# 用已有数据或预试验估计效应，模拟检验功效
m <- lmer(y ~ Treatment + (1|Block), data = meta)
power <- powerSim(m, test = fixed("TreatmentB", "t"), nsim = 100)
pc <- powerCurve(m, along = "Block", nsim = 100)

# 或用 pwr 包做粗略估算
library(pwr)
pwr.anova.test(k = 4, f = 0.4, sig.level = 0.05, power = 0.8)
```

田间试验 n=3 是常态，此时应当报告效应量与置信区间，用"效应量为 X（95% CI: a–b）"的表述，而不是"不显著"就结束讨论。不显著且 CI 窄（排除了生物学上重要的效应）是**有信息的结论**；不显著但 CI 宽是**证据不足**，两者写法完全不同。这一点写进论文能显著提高可信度。

## 六、处理缺失值与异常值

- 缺失值：不要用均值填补后再做 ANOVA（会低估方差）。混合模型可直接处理随机缺失（`lmer` 默认 na.omit，但会损失样本）；多重插补用 `mice`，在插补数据集上拟合模型再用 `pool()`。
- 异常值：先用 DHARMa 的 `testOutliers` 判定，不要凭 `boxplot` 就删。若确需剔除，报告剔除前后结果，并说明依据（仪器故障、记录错误等）。剔除后结论改变时，两个结果都要报告。

## 七、常见错误清单

- 同一小区多次采样，模型里没有小区随机效应（伪重复）。
- 区组当固定效应。
- 裂区设计只用单层随机效应。
- 计数数据直接 ANOVA。
- 不做残差诊断就报 p 值。
- 用 "p > 0.05" 论证"没有差异"。
- 多重比较不做校正，或校正后又按未校正的 p 值解读。
- 随机效应用 p 值决定去留。
- 柱状图不注误差棒类型。
- 只报 p，不报效应量与 CI。
- 奇异拟合（singular fit）警告被忽略。

