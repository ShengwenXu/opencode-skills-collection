---
name: "multivariate-community-stats"
description: "多变量与群落统计：排序方法选择、PERMANOVA 完整流程与 betadisper、驱动类群分解、mvabund、限制性置换"
---

# 多变量与群落统计（R）

专门处理"群落矩阵 × 环境矩阵"的分析决策：排序方法怎么选、组间差异怎么检验、离散度与位置差异怎么区分、哪些类群驱动了差异。微生物组、土壤动物、线虫群落、PLFA 数据都适用。

工具栈：`vegan`、`ade4`、`microeco`、`indicspecies`、`mvabund`。

## 一、排序方法选择：先判断梯度长度

```r
library(vegan)
dca <- decorana(otu_table(ps))
dca
```

DCA 第一轴长度决定响应模型：< 3 用线性方法（PCA/RDA/db-RDA），> 4 用单峰方法（CA/CCA），3–4 之间两种都做并比较解释力。

| 目的 | 方法 | 距离 | 注意 |
|---|---|---|---|
| 非约束（看整体结构） | PCoA / NMDS | 任意 | NMDS 需查 stress（< 0.2 可接受，< 0.1 好） |
| 线性非约束 | PCA | Aitchison（CLR 上欧氏） | 丰度数据别直接 PCA，先 CLR |
| 线性约束 | db-RDA | 任意 | 最通用，报告调整 R² |
| 单峰约束 | CCA | 卡方 | 对稀有类群敏感，考虑用 `downweight()` |
| 按分组约束 | CAP | 任意 | 便于画置信椭圆，但避免用 CAP 做假设检验（会过拟合） |

```r
# NMDS：多次随机起始，避免局部最优
nmds <- metaMDS(d_bc, k = 2, trymax = 100, autotransform = FALSE)
nmds$stress
stressplot(nmds)

# 置信椭圆 vs 置信区间：ellipse="confidence" 显示均值的不确定性，
# 若目的是显示样本分布用 "data"；两者含义不同，论文中要写明
ordiplot(nmds, type = "n")
points(nmds, display = "sites", col = as.numeric(meta$Group))
ordiellipse(nmds, meta$Group, kind = "se", conf = 0.95)
```

## 二、组间差异：PERMANOVA 的完整流程

**顺序不能变**：离散度检验 → PERMANOVA → 事后两两比较。

```r
library(vegan)
d <- vegdist(clr_mat, "euclidean")

# 1. 离散度齐性（必做）
bd <- betadisper(d, meta$Group)
permutest(bd, permutations = 999)
# p < 0.05：组间离散度不等。此时 PERMANOVA 的显著可能是离散度差异造成的
# 处理：报告离散度结果，并说明群落差异部分源于组内异质性
boxplot(bd)

# 2. PERMANOVA
adonis2(d ~ Group, data = meta, permutations = 999, by = "terms")

# 3. 事后两两比较（需校正）
library(pairwiseAdonis)
pairwise.adonis2(d ~ Group, data = meta, nperm = 999, p.adjust.method = "BH")
```

**关于 `by` 参数**：`by="terms"` 是顺序检验，变量进入顺序影响每一项的 R²；`by="margin"` 是偏效应（每一项控制其他项后）。多因子设计里报告哪种取决于你的问题——想说明"控制其他因子后 pH 是否仍重要"用 margin。不要只报 terms 然后按 R² 大小排序说"pH 最重要"。

**置换次数**：默认 999 够用于 p~0.05，但若 p 值接近阈值或发表高标准，用 9999。置换数影响 p 的精度（最小可能 p = 1/(nperm+1)）。

## 三、离散度差异本身可能就是结论

beta 多样性与群落异质性（如"处理提高了群落变异性"）是独立的研究问题，不要只把它当作 PERMANOVA 的前置检查。用 `betadisper` 的距离到质心作为响应变量做统计分析：

```r
bd <- betadisper(d, meta$Group)
cent <- data.frame(dist = bd$distances, Group = meta$Group, Block = meta$Block)
lmer(dist ~ Group + (1|Block), data = cent)   # 用混合模型
```

这个做法在生态学里有争议（距离到质心不是独立观测），但比只报 permutest 的 p 值信息量大。报告时要说明这一点。

## 四、驱动类群：从整体差异到具体分类单元

PERMANOVA 显著只说明"组间群落不同"，不说明"哪些类群不同"。三个层次的分解：

```r
# (1) 贡献分解：每个 ASV/OTU 对组间距离的贡献（simper）
sim <- simper(otu_table(ps_rel), meta$Group, permutations = 999)
summary(sim, ordered = TRUE, cutoff = 0.05)
# simper 会高估高丰度类群的贡献，只作为探索，不作统计结论

# (2) 约束排序的物种得分：哪些类群沿环境梯度变化
mod <- dbrda(d ~ pH + SOC, data = env)
scores(mod, display = "species", scaling = 2)[1:20, ]
# 只报告在轴上载荷高的类群，且给出载荷阈值

# (3) 指示物种分析（有分组时更合适）
library(indicspecies)
ind <- multipatt(t(otu_table(ps_rare)), meta$Group,
                 func = "r.g", control = how(nperm = 999))
summary(ind, alpha = 0.05, indvalcomp = TRUE)
# IndicatorValue = A（特异性）× B（保真度）；两者都高的才是好指示种
```

`multipatt` 的 `func` 参数：`"IndVal"`（默认）、`"IndVal.g"`（校正组间样本量不等）、`"r.g"`（相关型，适合丰度数据）。组间样本量不等时用带 `.g` 的版本。

## 五、mvabund：同时检验所有类群

当你想回答"整个群落层面是否有类群发生了变化"而不是逐个检验时，用 `mvabund`：

```r
library(mvabund)
Y <- mvabund(t(otu_table(ps_f)))
m <- manyglm(Y ~ Group, family = "negative_binomial", data = meta)
anova(m, p.uni = "adjusted", nBoot = 999)
# p.uni 给出每个类群的校正 p 值；整体 p 值（Res.Dev）是社区层面的检验
```

优点：控制族系错误率，且不依赖 PERMANOVA 的距离选择。缺点：对稀有类群敏感，需要先过滤；计算慢。

## 六、随机化检验的适用边界

PERMANOVA、Mantel、ANOSIM 都是置换检验，它们的有效性依赖：
- 样本可以交换（design 中没有时间自相关或空间梯度被忽略）。
- 置换方案匹配设计。分层设计要用 `strata`：

```r
adonis2(d ~ Treatment, data = meta, permutations = 999,
        strata = meta$Block)   # 区内置换，而不是全部乱序
```

- 空间自相关的数据（如沿样带采样）不能做自由置换，需要限制性置换（`permute::permute` 或 `restrict.perm`）。

ANOSIM 已被 PERMANOVA 取代（它只比较组间秩均值，不考虑离散度，且统计量不直接给出方差解释）。若旧稿里用了 ANOSIM，改为 PERMANOVA 并说明。

## 七、常见错误清单

- 不看 DCA 梯度长度就选 RDA 或 CCA。
- 丰度数据直接 PCA（未 CLR）。
- 只做 PERMANOVA 不做 betadisper。
- 多因子用 terms 的 R² 排序宣称哪个因子最重要。
- 置换不加 strata，区组结构被忽略。
- NMDS 只跑一个随机起始。
- 椭圆类型（confidence vs data）不注明。
- 用 simper 的贡献率做统计推断。
- 指示物种不报 A、B 两个分量。
- 用 CAP 做假设检验 p 值。
- PERMANOVA p 值卡在 0.05 边缘却只跑 999 次置换。

