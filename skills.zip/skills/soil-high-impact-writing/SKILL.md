---
name: soil-high-impact-writing
description: Draft, revise, and elevate soil-science manuscripts in a concise, high-evidence Nature- or Science-like style. Use when Codex needs to write or edit titles, abstracts, introductions, results, discussions, methods, figure legends, cover letters, reviewer responses, or full papers in soil science, biogeochemistry, pedology, soil ecology, land-use change, soil carbon, nitrogen cycling, soil microbiomes, greenhouse-gas fluxes, and related topics, especially when the source material is rough notes, mixed Chinese-English drafts, or section outlines that need sharper scientific prose.
---

# Soil High-Impact Writing

## Overview

Turn rough findings into precise, elegant soil-science prose for high-impact generalist journals and top specialist soil journals. Prioritize clarity, logic, quantitative grounding, and sentence economy over ornament, hype, or generic academic filler.

## Workflow

1. Diagnose the task before drafting.
   Determine the target section, journal family, audience breadth, and whether the user wants drafting, rewriting, shortening, translation, or structural repair.
2. Build an evidence map.
   Reduce the source material to five elements: question, gap, approach, decisive findings, and bounded implication. If key details are missing, state the missing element instead of inventing it.
3. Pick the journal mode.
   Use broader framing and faster payoff for Nature/Science-like prose. Use narrower claims and more site or process detail for specialist soil journals.
4. Draft from logic, not chronology.
   Put the main claim first, then the evidence, then the interpretation, then the boundary condition if needed.
5. Tighten aggressively.
   Cut throat-clearing, duplicated context, empty intensifiers, vague nouns, and any sentence that does not change what the reader knows.
6. Run an integrity pass.
   Separate observation from interpretation, association from causation, and finding from implication.

## Non-Negotiables

- Make every sentence do one job: context, gap, approach, result, interpretation, limitation, or implication.
- Lead with the scientific point, not the writing process.
- Prefer specific nouns and active verbs over nominalized phrases.
- Quantify whenever the evidence allows it. Include direction, magnitude, comparator, and uncertainty or statistical support when available.
- Use hedging precisely: `may`, `likely`, `consistent with`, `suggests`, `supports`, `is associated with`.
- Avoid empty emphasis such as `novel`, `interesting`, `important`, `remarkable`, `dramatic` unless the text immediately proves why.
- Keep soil terminology exact. Define specialized abbreviations at first use unless they are unquestionably standard for the target audience.
- Distinguish clearly among measured pattern, inferred mechanism, and broader consequence.
- Write for scientifically literate readers outside the immediate niche when the requested tone is Nature- or Science-like.
- If the input is in Chinese or mixed Chinese and English, recover the intended scientific meaning first and then write idiomatic scientific English instead of literal translation.

## Journal Modes

### Generalist Mode

Use this mode for Nature-, Science-, or Nature Communications-like prose.

- Open with the field problem or conceptual bottleneck, not local site history.
- Reach the central finding early.
- Explain specialized soil concepts at first mention.
- Keep only the methodological detail needed for credibility in the main narrative.
- End sections with what the finding changes in field-level understanding, prediction, or benchmarking.

### Specialist Soil-Journal Mode

Use this mode for journals such as *Geoderma*, *Soil Biology & Biochemistry*, *Plant and Soil*, or comparable outlets.

- Preserve mechanistic detail, site context, and soil-specific distinctions.
- Keep claims narrower and more conditional.
- Allow more operational detail in Results and Methods.
- Highlight horizon effects, fractionation schemes, biogeochemical pathways, and management context when they are central to interpretation.

## Section Rules

### Titles

- State the core variable, mechanism, or contrast and the system.
- Avoid filler frames such as `A study of`, `Insights into`, or `Evidence for` unless essential.
- Prefer compact titles with one clear conceptual center.
- Avoid unexplained abbreviations and stacked clause chains.
- Do not hide negative or null results. State them plainly when they are the contribution.

### Abstracts

- Build a compact arc: broad context, unresolved gap, approach, decisive findings, implication.
- Mention the study design in one clause, not a miniature Methods section.
- Put the main result in concrete terms, ideally with one to three decisive numbers.
- End with what the findings change in understanding, projection, or management relevance.
- Avoid literature review language, excessive caveats, and secondary findings.

### Introductions

- Move from broad field problem to the exact unresolved question.
- Keep only the background needed to understand the gap.
- End with the study objective, design logic, and, when appropriate, a short statement of the main finding or hypothesis.
- Avoid encyclopedic summaries of everything known about soils, carbon, microbes, or climate.

### Results

- Organize by question, not by the order in which analyses were run.
- Open each paragraph or subsection with the answer.
- Follow immediately with the evidence: comparison, effect size, direction, variability, model skill, or test statistic as appropriate.
- Keep interpretation light. Save most mechanism and significance claims for Discussion.
- Use subheadings that reflect findings, not generic labels such as `Soil properties` or `Additional analyses`.

### Discussion

- Start by answering the main question directly.
- Explain what the findings mean, why they matter, and where the inference stops.
- Compare with prior work only when comparison sharpens interpretation.
- Calibrate limitations. Acknowledge them clearly, but also state what remains robust.
- End with the most defensible broader implication, not a slogan.

### Methods

- Optimize for reproducibility and auditability.
- Preserve site information, sampling depth, dates or seasons, extraction or fractionation procedures, instrument and software versions, model names, transformations, thresholds, and statistical criteria.
- Remove rhetorical justification that belongs in the Introduction or Discussion.
- Keep tense and level of detail consistent across subsections.

## Common Repair Moves

- Replace vague openings such as `Soils play an important role...` with the most relevant functional context.
- Replace stacked claims with one claim and one support sentence.
- Replace noun-heavy phrases with verbs.
- Convert causal overreach into accurate association language unless the design supports causality.
- Separate what was measured from what was inferred.
- Remove repeated definitions once a term has been established.
- Cut any adjective that does not change interpretation.

## Output Modes

- Draft a section from bullet notes, tables, or figure takeaways.
- Rewrite rough English into journal-ready prose.
- Translate Chinese notes into polished scientific English.
- Compress verbose text into tighter high-impact prose.
- Expand concise findings into full Results, Discussion, or Methods sections.
- Retune a draft toward generalist or specialist-journal style on request.

## References

- Read `references/style-signals.md` when tone, structure, and journal-style cues matter.
- Read `references/section-blueprints.md` when drafting or repairing a specific manuscript section.
