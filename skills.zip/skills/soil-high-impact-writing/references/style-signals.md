# Style Signals

Use this file when the user wants prose that feels publishable in a high-impact soil-science context rather than merely grammatically correct.

## Source Base

These signals are distilled from current or accessible journal guides and published soil-related papers:

- Nature formatting guide:
  `https://www.nature.com/nature/for-authors/formatting-guide`
- Nature content-type pages showing repeated section logic across journals:
  `https://www.nature.com/ncomms/submit/content-types`
  `https://www.nature.com/nmeth/content`
  `https://www.nature.com/nsmb/content`
- Nature Methods editorial on clarity and story line:
  `https://www.nature.com/articles/nmeth0106-1`
- Soil-related exemplars:
  `https://www.nature.com/articles/s41467-023-38905-8`
  `https://www.nature.com/articles/s41561-024-01384-7`
  `https://www.sciencedirect.com/science/article/pii/S0016706124002210`
  `https://www.sciencedirect.com/science/article/pii/S0016706125004756`
- Soil-journal scope signal:
  `https://www.sciencedirect.com/journal/soil-biology-and-biochemistry`

Science-specific stylistic cues in this skill are inferred from broadly shared high-impact scientific prose conventions rather than from a single authoritative Science author-guide page. If the user asks for exact target-journal formatting, inspect the current author instructions for that journal.

## What Repeats Across High-Impact Writing

### 1. The story line is visible early

High-impact papers do not make the reader excavate the point. They surface the problem, the gap, and the central answer quickly.

Operational rule:

- State the unresolved problem within the first few sentences.
- State the answer early in the abstract and early in the Results.
- Do not bury the contribution under methodological setup.

### 2. Broad-access clarity matters

Nature explicitly asks authors to write for readers outside the immediate discipline, minimize jargon, explain the background and rationale clearly, and keep titles and abstracts intelligible to any scientist.

Operational rule:

- Explain specialist soil terms on first use when writing for generalist journals.
- Prefer `mineral-associated organic matter` on first use, then `MAOM`.
- Avoid abbreviation clusters in titles and first sentences.

### 3. Abstracts are compressed arguments, not inventories

Nature-style abstracts or summary paragraphs move through a strict logic: field context, gap, approach, main findings, and general implication.

Operational rule:

- Use one sentence for context and gap.
- Use one sentence for study design or evidence base.
- Use two or three sentences for decisive findings.
- End with the conceptual or predictive consequence.

### 4. Results are answer-first

In strong papers, Result paragraphs begin with the conclusion of the analysis, then support it with data. The data do not arrive before the claim they justify.

Operational rule:

- First sentence: the answer.
- Second and third sentences: evidence with numbers or tests.
- Final sentence: local interpretation or transition.

### 5. Discussion interprets; it does not replay the Results

The strongest Discussions answer three questions: what does this mean, why does it matter, and what are the limits of that inference.

Operational rule:

- Open by restating the answer to the main question.
- Use comparison with prior work only to sharpen interpretation.
- End with a bounded implication, not a slogan.

### 6. Methods are exact but unemotional

High-level papers keep Methods factual, reproducible, and free of argument.

Operational rule:

- Include site, depth, timing, sample counts, analytical pipeline, software, versions, and statistics.
- Exclude claims of importance, novelty, or success from Methods.

## Soil-Specific Signals from the Sampled Literature

### Name the soil entity precisely

Strong soil papers distinguish among SOC, SOM, MAOM, POM, DOC, horizon, depth, land use, mineral association, and microbial process. They do not blur pools, fractions, and functions into the generic word `soil`.

Operational rule:

- Replace `soil carbon changed` with the exact pool or fraction that changed.
- Replace `microbial activity` with the measured process or guild when known.

### Keep system and scale visible

Published soil papers anchor claims to system and scale: forest soils, cropland topsoils, prairie subsoils, global meta-analysis, profile depth, horizon, site count, or model ensemble.

Operational rule:

- Mention the relevant system in the title or first abstract sentence.
- Mention scale in the abstract if it changes interpretation.

### Quantify contrasts, especially for null or surprising findings

The Geoderma negative-result exemplar states the null result directly and supports it with sample size and design. It does not soften the result into ambiguity.

Operational rule:

- If the main contribution is a null or counterintuitive finding, say it plainly.
- Support it with comparison, sample size, and analytical control.

### Link mechanism only as far as the evidence allows

The Nature Communications and Nature Geoscience exemplars connect patterns to governing variables or pool structure, but keep the inferential step legible.

Operational rule:

- Use `is associated with`, `indicates`, `supports`, or `is consistent with` when the study is observational or model-assisted.
- Reserve stronger causal phrasing for manipulative or otherwise causal designs.

### Carry management or modeling implications only when grounded

Specialist soil journals tolerate more management context; generalist journals favor implications for carbon-cycle understanding, benchmarking, or prediction.

Operational rule:

- Choose the ending register that matches the outlet.
- For generalist prose, end on what the findings change in understanding or prediction.
- For specialist prose, end on process, restoration, management, or site-specific inference if that is the true contribution.

## Sentence-Level Preferences

Prefer:

- concrete verbs over abstract nouns
- one clause carrying one main claim
- short transitions with semantic value
- calibrated hedging
- explicit comparators

Avoid:

- `plays an important role` unless the role is immediately specified
- `it is worth noting that`
- `interestingly`
- `in order to`
- `a growing body of literature`
- `furthermore` repeated as structural glue
- padded claims such as `provides new insights into`

## Calibration Guide

Use stronger phrasing only when the evidence supports it:

- Strong: `drives`, `controls`, `determines`, `causes`
- Moderate: `regulates`, `shapes`, `constrains`
- Careful: `is associated with`, `tracks`, `correlates with`, `is consistent with`

When uncertain, choose the more defensible verb.
