# Section Blueprints

Use these blueprints when drafting or repairing specific manuscript sections.

## Abstract Blueprint

Target logic:

1. Field context
2. Exact gap
3. Study design or evidence base
4. Main finding
5. Secondary decisive finding if needed
6. Bounded implication

Compression rules:

- Keep only one problem statement.
- Mention only the methods detail needed to interpret the result.
- Include numbers only for findings that carry the abstract.
- End with the change in understanding, prediction, or management relevance.

Diagnostic questions:

- Can a reader state the gap after sentence two?
- Is the main result obvious before the last line?
- Does the last sentence say what changed, not just that the study is important?

## Introduction Blueprint

Paragraph 1:

- Frame the broad problem in the most relevant disciplinary language.
- Narrow immediately toward the soil process, pool, organism, or land-use contrast that matters.

Paragraph 2:

- Explain the bottleneck in current understanding.
- Use prior literature selectively and only to expose the gap.

Final paragraph:

- State the study objective, question, or hypothesis.
- Give the core design in one sentence if helpful.
- Optionally preview the main finding when the journal style supports it.

Do not:

- open with generic ecosystem-service praise
- review the entire field
- state three different gaps when only one drives the paper

## Results Blueprint

### Result paragraph template

Sentence 1:
State the answer.

Sentence 2:
Give the key evidence with direction and comparator.

Sentence 3:
Add quantitative support such as effect size, uncertainty, or model performance.

Sentence 4:
Give a local interpretation or segue.

### Result subsection template

- Opening sentence: question addressed by the subsection
- First paragraph: principal finding
- Second paragraph: supporting pattern or robustness analysis
- Optional final paragraph: heterogeneity, boundary condition, or exception

Do not:

- begin with `Figure 2 shows`
- narrate analyses in the order they were run
- repeat every numeric detail already visible in the figure

## Discussion Blueprint

Opening paragraph:

- Answer the main question directly.
- State the most important mechanistic or conceptual meaning.

Middle paragraphs:

- Compare with the most relevant prior studies.
- Explain why the pattern emerged.
- Mark boundary conditions and remaining uncertainty.

Final paragraph:

- State the strongest defensible implication.
- Match the outlet: field-level implication for generalist journals, process or management implication for specialist journals.

Do not:

- replay the Results paragraph by paragraph
- inflate one-site findings into universal rules
- hide limitations in the last sentence

## Methods Blueprint

Recommended subsection order:

1. Study system or site description
2. Experimental or sampling design
3. Laboratory or analytical procedures
4. Data processing
5. Statistical analysis
6. Code or model details when relevant

Rules:

- Keep nouns concrete: horizon, depth, incubation temperature, extraction ratio, instrument model, software version.
- Report decision thresholds and transformations.
- Distinguish prespecified analyses from exploratory analyses when relevant.
- Keep syntax flat and readable; Methods need not sound elaborate to sound rigorous.

## Revision Passes

### Pass 1: Logic

- Can each paragraph be summarized in one sentence?
- Does each paragraph open with its point?
- Is the section solving one clear rhetorical job?

### Pass 2: Evidence

- Does each major claim have visible support?
- Are direction, magnitude, and comparator all present where needed?
- Is causal language justified?

### Pass 3: Style

- Remove filler transitions.
- Cut repeated nouns and definitions.
- Replace nominalizations with verbs.
- Shorten overbuilt sentences.

### Pass 4: Integrity

- Separate result from inference.
- Separate inference from implication.
- Mark missing information rather than guessing.

## Quick Rewrite Patterns

Weak:
`Soil carbon is an important component of terrestrial ecosystems and has received increasing attention in recent years.`

Stronger:
`Soil carbon storage governs a major terrestrial feedback to climate, yet the controls on its persistence remain unresolved.`

Weak:
`Figure 3 shows that the organic treatment had higher microbial biomass.`

Stronger:
`Microbial biomass was higher under organic management than under conventional management, indicating a larger active microbial pool in amended soils.`

Weak:
`These findings provide new insights into the mechanism.`

Stronger:
`These findings suggest that mineral association, rather than bulk carbon content alone, constrains the temperature sensitivity of soil carbon loss.`
