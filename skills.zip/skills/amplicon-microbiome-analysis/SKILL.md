---
name: "amplicon-microbiome-analysis"
description: "R/phyloseq 的 16S/ITS 扩增子下游分析：归一化策略、alpha/beta 多样性、PERMANOVA、差异丰度与出图规范"
---

# 16S/ITS 扩增子下游分析（R）

用于从 ASV 表 + 分类表 + 元数据出发，做规范的微生物组下游分析。假定上游（QIIME2 / DADA2 / vsearch）已完成，得到 feature table、taxonomy、representative sequences 和 sample metadata。

工具栈：`phyloseq`（数据结构与多样性）、`vegan`（排序与 PERMANOVA）、`microbiome` / `microeco`（组成与差异）、`ANCOMBC2` 或 `DESeq2`（差异丰度）、`ggplot2` + `patchwork`（出图）。

## 一、开工前的数据检查

不要跳过这一步。绝大多数扩增子分析的错误出在数据结构上，不是统计方法上。

```r
library(phyloseq); library(microbiome); library(vegan)

ps <- readRDS("ps.rds")
ps
# 检查 1：元数据里没有空层级因子（会破坏按组拆分）
meta <- data.frame(sample_data(ps))
str(meta)
lapply(meta[sapply(meta, is.factor)], droplevels)  # 每组因子水平都要有样本
table(meta$Group)   # 任何一组 n < 3 就放弃组间推断

# 检查 2：测序深度分布，决定是否稀释/过滤
depths <- sample_sums(ps)
summary(depths)
hist(log10(depths), breaks = 30)
# 深度相差超过一个数量级（>10x）时，CLR/rarefy 的选择会显著影响结论，需做敏感性分析

# 检查 3：ASV 表里有没有非细菌/古菌（叶绿体、线粒体）或未分类
ps <- subset_taxa(ps, !is.na(Phylum) & Phylum != "" )
ps <- subset_taxa(ps, !(Order %in% c("Chloroplast")) & !(Family %in% c("Mitochondria")))
# ITS 数据没有叶绿体问题，但要去掉未分类到界的序列

# 检查 4：低丰度 ASV 过滤。常用：至少在 10% 样本中出现且总丰度 > 10 reads
ps_f <- filter_taxa(ps, function(x) sum(x > 0) >= 0.1*nsamples(ps) & sum(x) > 10, TRUE)
```

把过滤前后的 ASV 数与 reads 保留比例记下来，写进论文的方法部分。审稿人会问。

## 二、归一化：先定策略再分析

三种主流做法，各有前提，**不要混用**：

**rarefy（稀释到统一深度）**：最简单，适合 alpha 多样性（必须做，否则多样性值是深度的函数）。缺点：丢弃数据，随机种子影响结果。

```r
set.seed(1234)
ps_rare <- rarefy_even_depth(ps_f, sample.size = min(sample_sums(ps_f)),
                             rngseed = 1234, replace = FALSE, trimOTUs = TRUE)
```

**CLR（中心对数比）**：适合组成型数据的差异丰度与多变量分析（beta 多样性、网络、机器学习）。需要先做伪计数。

```r
ps_clr <- microbiome::transform(ps_f, "clr")   # 默认伪计数 1，已处理的 ASV 表够用
# 更稳健：用 zCompositions 的 cmultRepl 估计零值
```

**TSS / 相对丰度**：只用于可视化和组成描述，不要用它跑 PERMANOVA 或差异检验——相对丰度总和为 1，会引入伪相关，PERMANOVA 的置换检验在这种约束下失去意义。

规则：alpha 多样性用 rarefy 后的表；beta 多样性与差异丰度用 CLR（或用 Aitchison 距离）；作图用相对丰度。

## 三、Alpha 多样性

```r
library(microeco)  # 或直接用 phyloseq::estimate_richness

alpha <- estimate_richness(ps_rare, measures = c("Observed", "Shannon", "Simpson"))
alpha$Group <- sample_data(ps_rare)$Group

# 组间比较：先查分布，再选检验
shapiro.test(alpha$Shannon)                     # 正态性
car::leveneTest(Shannon ~ Group, data = alpha)  # 方差齐性
# 都满足 -> aov + TukeyHSD；否则 -> kruskal.test + dunn.test / FSA::dunnTest

# 更好的做法：用混合模型把测序深度和区组作为协变量（见 field-experiment-stats 技能）
library(lme4); library(emmeans)
m <- lmer(Shannon ~ Group + scale(log(depths)) + (1|Block), data = alpha)
anova(m); emmeans(m, pairwise ~ Group, adjust = "tukey")
```

报告时给效应量（η² 或组间均值差 + 95% CI），不要只给 p。n=3 的组间 p 值不可靠，这是常识但论文里常被忽略。

## 四、Beta 多样性

距离选择：**Bray-Curtis**（丰度加权，最常用）；**UniFrac**（加权=丰度加权且考虑系统发育，非加权=只看有无）；**Aitchison**（欧氏距离在 CLR 空间，对组成型数据统计性质最好，配 PERMANOVA 时解释力更干净）。不要在同一张图上混用不同距离的结论。

```r
# 计算距离
d_bc  <- phyloseq::distance(ps_clr, method = "bray")
d_ait <- phyloseq::distance(ps_clr, method = "euclidean")  # on CLR = Aitchison
# UniFrac 需要树
d_uf  <- UniFrac(ps_rare, weighted = TRUE, normalized = TRUE)

# 排序
ord <- ordinate(ps_clr, method = "PCoA", distance = d_ait)
plot_ordination(ps_clr, ord, color = "Group") + stat_ellipse()

# PERMANOVA：先检验离散度齐性，否则组间差异可能是离散度差异
bd <- betadisper(d_bc, sample_data(ps_clr)$Group)
permutest(bd)                      # p < 0.05 意味着离散度不等，PERMANOVA 结果不可信
adonis2(d_bc ~ Group, data = meta, permutations = 999, by = "terms")

# 多因子设计：不要写 a*b，要写清边际检验
adonis2(d_bc ~ Group * Depth, data = meta, permutations = 999, by = "terms")
# by="terms" 时各项是顺序（sequential）检验，顺序会影响结果；用 by="margin" 做偏效应
```

关键陷阱：`adonis2` 的 `R²` 是模型中该项解释的方差比例，多因子下各项 R² 不可直接比较大小来排重要性，除非用 `by="margin"` 并注意总解释量。总 R² 加起来接近 1 时说明元数据过拟合（变量数接近样本数），必须做前向选择或交叉验证。

样本数少于变量数 × 5 时，别做 PERMANOVA 多因子模型，只做单因子。

## 五、群落组成与差异丰度

```r
# 门/属水平组成条形图（相对丰度）
ps_rel <- microbiome::transform(ps_f, "compositional")
plot_composition(ps_rel, taxonomic.level = "Phylum") +
  scale_fill_brewer(palette = "Set3")

# 差异丰度：三种方法，各有假设
# (1) ANCOMBC2 —— 推荐，控制假发现率且处理组成型数据
library(ANCOMBC)
out <- ancombc2(ps_f, tax_level = "Genus", fix_formula = "Group",
                rand_formula = "(1|Block)",   # 有区组时加
                p_adj_method = "BH", prv_cut = 0.1)
# 只认 passed_ss = TRUE 的项

# (2) DESeq2 —— 快速，但负二项模型假设与组成型数据不完全匹配，只作交叉验证
# (3) LEfSe / microeco 的 trans_diff —— 便于出图，但方法学上不如 ANCOMBC2 严格

# 交叉验证：两种方法都显著的属，结论强度写"robust"；只有一种显著的，写"trend"并给两法结果
```

差异丰度报告必须给：方法名、多重比较校正方式、效应量（log fold change 或 CLR 均值差）、以及是否在独立数据中验证。只报 p 值的差异丰度表在好刊物上会被质疑。

## 六、指示物种与贡献物种

```r
library(indicspecies)
ind <- multipatt(otu_table(ps_rel) |> t(), meta$Group, control = how(nperm = 999))
summary(ind, indvalcomp = TRUE)   # 只保留 A（特异性）和 B（保真度）都高的

# 用 randomForest 找区分组的属，配合交叉验证（见 soil-microbe-predictive-modeling 技能）
```

## 七、出图与报告规范

图要有：坐标轴上的解释方差比例（PCoA1 32.4%）、样本数、统计检验结果直接标在图上（R² 与 p）。alpha 多样性图用箱线 + 散点（不要只用柱状 + 误差棒，会隐藏分布）。组成图把丰度 < 1% 的合并为 "Other" 并在图例注明阈值。

方法部分必须写清：测序平台与区域、上游流程与版本、过滤参数、归一化策略、距离度量、PERMANOVA 的置换次数与设计公式、差异丰度方法与校正方式、软件版本。

## 八、常见错误清单

- 用了相对丰度跑 PERMANOVA 或 DESeq2（组成型约束被忽略）。
- 不同样本深度差异巨大却不做敏感性分析。
- betadisper 不显著就直接信 PERMANOVA（必需做，但记住它检验的是离散度，不显著只是必要条件）。
- n=3 分组做 Tukey 后报告 p<0.05 就宣称"显著提高"。
- 差异丰度只报属名和 p 值，不给效应量。
- 把 ASV 数和物种数混为一谈（ASV 不是物种）。
- 16S 结果直接推断功能（"该属丰度升高说明固氮增强"）——需要 PICRUSt2 或宏基因组支持才能这么说。
- ITS 数据用了细菌的 16S 数据库注释。

