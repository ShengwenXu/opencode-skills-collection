---
name: "metagenomics-functional-analysis"
description: "宏基因组与功能基因分析：HUMAnN3/KEGG/CAZy 组成型数据的 CLR 处理、ALDEx2 差异、Procrustes、功能冗余判断与报告规范"
---

# 宏基因组与功能基因分析（R）

用于 shotgun 宏基因组、功能基因 qPCR 丰度、以及从扩增子预测的功能谱（PICRUSt2 / Tax4Fun2）的统计分析与解释。重点是：功能谱是组成型数据，方法选择与扩增子分析不同。

## 一、数据来源与各自的坑

**HUMAnN3 输出**（`genefamilies.tsv`、`pathabundance.tsv`）：已按 CPM 归一化，但仍是组成型。层级的 `UNMAPPED`、`UNINTEGRATED` 行要检查——如果 `UNMAPPED` 比例超过 40%，说明参考库覆盖不足，功能推断的可靠性要打折，且这与处理组相关时（比如某处理富集了参考库外的类群）会引入系统性偏差。

**KEGG KO / CAZy 丰度表**：从 HUMAnN3 映射或从 MAG 注释汇总。注意 KEGG 层级（L1/L2/L3）是嵌套的，同一 KO 会在多个通路里重复计数，做通路水平分析前要明确是"通路丰度"（HUMAnN3 策略：通路内取最小丰度，避免重复）还是"KO 汇总到通路"（会重复计数）。

**PICRUSt2 预测**：只是预测，不等于测量。论文里必须写"predicted"，且不能用于主张"该功能增强了"。要用 PICRUSt2 的 NSTI 值过滤（> 2 的 ASV 丢掉）。

**功能基因 qPCR**（如 nifH、amoA、nirK、nirS、pmoA）：这是绝对丰度，不是组成型数据，可以直接做参数统计。但要按每克干土或每 ng DNA 归一，两者不能混。报告时给拷贝数/g 干土。

## 二、组成型数据的正确处理

基因丰度表按列和为常数，直接做相关分析会引入伪相关（丰度升高必然压低其他项）。三种处理：

```r
# CLR（推荐用于多变量分析与差异检验）
library(microbiome)
ps_fun <- phyloseq(otu_table(fun_mat, taxa_are_rows = TRUE), sample_data(meta))
ps_clr <- transform(ps_fun, "clr")   # 加伪计数
# 零值多时用 zCompositions::cmultRepl 先估计替换，再 CLR
library(zCompositions)
fun_nz <- cmultRepl(t(fun_mat), method = "CZM", output = "p-counts")
fun_clr <- apply(log(as.matrix(fun_nz) + 1e-6), 2, function(x) x - mean(x))
```

也可以用 `ALDEx2`（内部做 Monte Carlo 零值估计，直接给 CLR 与差异检验）或 `propr`（专门算组成型数据的相关，替代 Pearson）。

**不要做的事**：把 KEGG 通路丰度直接和土壤理化指标做 Pearson 相关矩阵。两个组成型或一个组成型一个非组成型的变量之间的相关没有清晰解释。改用 CLR 后的 Spearman（保守）、或用 `propr` 的 rho/phi 统计量。

## 三、功能谱的整体结构分析

```r
library(vegan)
d_bc <- vegdist(fun_clr, method = "euclidean")   # CLR 空间 = Aitchison 距离

# 排序 + PERMANOVA（先查离散度）
bd <- betadisper(d_bc, meta$Group); permutest(bd)
adonis2(d_bc ~ Group * Depth, data = meta, permutations = 999, by = "margin")

# 功能谱 vs 分类谱的一致性：Procrustes
d_tax <- vegdist(clr_tax, "euclidean")
pr <- protest(cmdscale(d_tax, k = 2), cmdscale(d_bc, k = 2), permutations = 999)
# correlation 高说明功能差异主要跟随群落组成；低说明存在功能冗余
```

Procrustes 的结果是很多论文里被误用的地方：高相关只说明两个相似性矩阵的排序结构一致，不说明因果。功能冗余的论断需要结合"功能多样性高但分类多样性低"这类证据。

## 四、功能差异分析

按分析目的选方法，三者不可互换：

```r
# (1) 组间差异通路/KO：ALDEx2，组成型数据的标准做法
library(ALDEx2)
res <- aldex.clr(fun_mat, conds = meta$Group, mc.samples = 128, denom = "iqlr")
test <- aldex.ttest(res, paired = FALSE)
eff <- aldex.effect(res)
sig <- cbind(test, eff)
# 同时看 we.ep（期望 p）与 effect（效应量）；|effect| < 1 的项即使显著也意义有限

# (2) 通路水平富集：KO 显著项映射到 KEGG 通路，用过表征分析
library(clusterProfiler); library(KEGGREST)
# 注意背景集要用本研究的全部检测到的 KO，不是全 KEGG 宇宙
# 否则富集结果反映的是"检测失败"而非生物学

# (3) 功能基因 qPCR 的组间比较：直接参数/非参数检验
# 拷贝数取 log10 后做 ANOVA/lmer；不要用原始拷贝数（右偏严重）
```

功能差异报告要区分：**丰度变化**（某通路更多/更少）与**活性变化**（需要转录组或酶活数据）。宏基因组只能说明潜力。论文里写 "the potential for denitrification was higher" 是准确的；写 "denitrification was higher" 需要额外证据。

## 五、CAZy 与碳降解功能

CAZy 家族按底物类别（GH、GT、PL、CE、AA、CBM）汇总后做组成分析。常见的分析角度：

- 碳水化合物活性酶的多样性（Shannon）与土壤有机质的关系
- 特定底物类别（如纤维素降解 GH5/GH48）沿有机质梯度的变化
- CAZy 与分类群的贡献分解（哪个门贡献了哪个家族）

```r
# 贡献分解：把家族丰度按分类来源拆解（需要 HUMAnN3 的 stratified 输出）
# 不用 phyloseq，直接处理 strat 表
strat <- read.delim("genefamilies_stratified.tsv")
# 行名格式：UniRef90_XXX|g__Genus.s__Species
```

有 stratified 数据时做贡献分解，比只报"CAZy 总量升高"有信息量得多。

## 六、MAG 相关（若从宏基因组组装）

如果分析基于 MAG（metagenome-assembled genomes）：

- 完整度 > 70%、污染 < 10%（CheckM2）是常用门槛，低于此的 MAG 不应用于定量
- 丰度是 mapping 回 reads 得到的覆盖度，不是组装深度
- MAG 之间的比较要考虑基因组大小差异（用相对丰度，且明确是否按基因组长度校正）

## 七、报告规范

方法部分写清：测序深度与平台、组装/注释流程与数据库版本（HUMAnN3 的数据库版本、KEGG 版本日期）、归一化策略、统计方法与校正方式、以及是否用 stratified 输出做贡献分解。

结果里给效应量。功能谱的解释要节制：宏基因组是潜力，不是活性；是群落水平的汇总，不是单个类群的行为（除非有 stratified 数据）。

## 八、常见错误清单

- KEGG 通路直接做 Pearson 相关矩阵（组成型数据伪相关）。
- 用相对丰度做差异检验而不做 CLR 或 ALDEx2。
- 把 PICRUSt2 预测功能写成实测功能。
- 通路富集的背景集用了全 KEGG 而非本研究检测到的 KO。
- 只报显著通路，不报效应量与检测比例。
- 把"通路丰度升高"直接解释为"过程速率提高"。
- qPCR 拷贝数不取对数就做 ANOVA。
- 未检查 UNMAPPED 比例，也未检查其是否与处理相关。

