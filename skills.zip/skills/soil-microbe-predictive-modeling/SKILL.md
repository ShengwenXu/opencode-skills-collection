---
name: "soil-microbe-predictive-modeling"
description: "土壤与微生物数据的预测建模：空间/分组交叉验证、ranger 调参与置换重要性、SHAP/ALE 解释、预测与推断的区分"
---

# 土壤–微生物预测建模（R）

用于用土壤理化、气候、管理措施等变量预测微生物属性（多样性、生物量、功能基因丰度、群落组成），或用群落数据预测土壤功能。重点是**验证方案必须与数据结构匹配**——这是这类研究最常被推翻的地方。

工具栈：`tidymodels`（统一流程）或 `caret`、`randomForest` / `ranger`、`xgboost`、`DALEX` / `iml` / `vip`（解释）、`blockCV`（空间交叉验证）。

## 一、先判断数据结构，再选验证方案

三种情况，验证方式完全不同：

**独立样本（实验室/温室，随机布置）**：k 折交叉验证（k = 5 或 10）足够。

**田间试验、有区组或站点结构**：必须按区组/站点分组交叉验证（leave-one-site-out 或 leave-one-block-out）。若随机分折，同一小区或同一站点的样本会同时出现在训练集与测试集里，模型会"记住"站点特征，性能被严重高估。

**空间梯度采样**：必须用空间分块交叉验证。土壤属性有强空间自相关，随机分折会让邻近样本分到两侧。

```r
library(blockCV)
# 用坐标建空间折
sb <- cv_spatial(x = coords, size = 5000, k = 5, selection = "random", progress = FALSE)

# 分组折（按站点/区组）
folds <- groupKFold(meta$Site, k = 5)   # caret
# 或 tidymodels: group_vfold_cv(data, group = Site, v = 5)
```

诊断信号：随机 CV 的 R² 是空间 CV 的两倍以上，说明空间自相关在替你打分，报告的空间 CV 结果才是可信的。

## 二、基线模型必须先有

任何机器学习模型都要和一个简单基线比：用均值预测（R² = 0）、用最强单变量线性回归、或用已知的文献关系。模型性能没有超过基线，说明这套预测变量没有信息量。很多论文只报"随机森林 R² = 0.72"而不给基线，无法判断这是不是只是土壤有机质的线性效应。

## 三、随机森林：正确用法

```r
library(ranger); library(tidymodels)

set.seed(123)
rf_spec <- rand_forest(mtry = tune(), min_n = tune(), trees = 1000) |>
  set_engine("ranger", importance = "permutation") |>
  set_mode("regression")

# 调参必须在训练折内做，不能在整个数据集上调完再交叉验证
wf <- workflow() |> add_model(rf_spec) |> add_formula(y ~ .)
tuned <- tune_grid(wf, resamples = folds, grid = 30,
                   metrics = metric_set(rmse, rsq, mae))
final <- finalize_workflow(wf, select_best(tuned, "rmse"))
fit  <- last_fit(final, split = initial_split)
collect_metrics(fit)
```

**变量重要性**：用置换重要性（permutation importance），不要用 Gini/不纯度重要性——后者对连续变量和高基数变量有系统性偏好。`ranger` 的 `importance = "permutation"` 是正确做法；更严格用 `vip::vi()` 配合 `vi_permute()`，在**测试折**上算。

**重要性的解读边界**：置换重要性在相关变量之间会被稀释（两个高度相关的变量各自重要性都不高）。所以要报告变量间的相关性结构，或做分组重要性（把相关变量合成一组后一起置换）。

```r
library(vip)
vi(fit, method = "permute", train = train_df, target = "y",
   metric = "rmse", pred_wrapper = predict)
```

**部分依赖（PDP）**：显示单个变量的边际效应。但当变量相关时，PDP 会在特征空间外推（生成现实中不存在的组合）。用 ALE（累积局部效应，`ALEPlot` 或 `iml::FeatureEffect(method="ale")`）替代，或至少报告相关性并说明 PDP 的局限。

## 四、模型解释：从重要性到机制

重要性排序不等于机制。要做的事：

```r
library(DALEX); library(DALEXtra)
explainer <- explain_tidymodels(fit, data = X_test, y = y_test,
                                label = "RF", verbose = FALSE)
# 变量贡献（break-down）
bd <- model_parts(explainer, B = 10)
plot(bd)

# 单个观测的解释
plot(model_breakdown(explainer, new_observation = X_test[1, ]))

# SHAP
library(fastshap)
shap <- explain(X_test, explainer = pred_fun, nsim = 100, feature_names = names(X_test))
autoplot(shap) + ggbeeswarm::geom_quasirandom()
```

SHAP 值的解读：它告诉你"该特征把预测值推高/推低多少"，不告诉你因果方向。特征重要性高只说明模型用它，可能是替代了另一个未测量的真实驱动因子。

论文里写"pH 是驱动 Shannon 指数最重要的因子（SHAP 均值 0.12）"是描述性的；写"pH 调节了多样性"需要实验或因果推断设计。这个区分在审稿中经常被追问。

## 五、预测 vs 推断：不要混

两类目标，方法选择不同：

**预测**（要准确预测新样本的属性）：可以堆变量、用非线性模型、用集成方法。评估看测试集 RMSE/R²。变量重要性只是副产品。

**推断**（要说明哪个因子驱动了响应）：用可解释的模型（线性/混合模型、GAM），报告系数与 CI，做残差诊断。不要用随机森林的重要性来做推断——它没有系数、没有标准误、没有方向性检验。

土壤微生物研究里 90% 的"驱动因子"问题本质是推断问题，却用了预测方法。如果你要写"某因子驱动了群落变化"，用 RDA + 方差分解（见 soil-microbe-integrated-analysis 技能）或 SEM，随机森林只作为补充。

## 六、样本量与过拟合

经验规则：参数/变量的数量应使样本数至少是其 10 倍（回归）；随机森林在 n < 50 时通常不稳定，n < 30 不要做多变量机器学习。

```r
# 学习曲线：判断样本量是否足够
lc <- learning_curve_dat(dat = df, outcome = "y", test_prop = 1/4,
                         verbose = FALSE, method = "rf")
ggplot(lc, aes(x = Training_Size, y = RMSE, color = Data)) +
  geom_smooth(se = FALSE)
# 测试集 RMSE 随训练集增大仍在下降 = 样本不足
```

报告要给测试集性能的变异（多次重复 CV 的均值 ± SD），不是单次划分的一个点估计。

## 七、常见错误清单

- 随机 k 折用在有空间自相关或分组结构的数据上。
- 在全数据集上调参后再交叉验证（信息泄漏）。
- 用 Gini 重要性代替置换重要性。
- 重要性排序后直接做因果解释。
- 没有基线模型。
- 只报测试集 R²，不报 RMSE/MAE，也不报基线。
- n < 30 仍做多变量机器学习。
- 相关变量间的重要性差异被过度解读。
- PDP 用在外推区域，变量相关时不说明。
- 分类任务不看类别不平衡，只报准确率。
- 用同一批数据既选特征又评估性能。

